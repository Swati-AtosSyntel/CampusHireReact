﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CatalogService.Models
{
    public class DatabaseContext:DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options):base(options)
        {
            
        }
        public DbSet<Category> categories { get; set; }
        public DbSet<Product> products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                new Category
                {
                    CategoryID = 1,
                    Name = "Electronics"

                },
                new Category
                {
                    CategoryID = 2,
                    Name = "Clothes"

                },
                new Category
                {
                    CategoryID = 3,
                    Name = "Grocery"

                }
            );
            modelBuilder.Entity<Product>().HasData(
                new Product
                {
                    ProductID = 123,
                    ProductName = "Dell Laptop",

                    CategoryID = 1

                },
                new Product
                {
                    ProductID = 124,
                    ProductName = "Jeans",

                    CategoryID = 2
                }

            );
        }

    }
}

