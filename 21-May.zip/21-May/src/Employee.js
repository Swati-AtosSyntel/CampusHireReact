import React,{Component} from 'react';

class Employee extends React.Component{
    constructor(){
        super();
        this.state={data:"React JS helps to build complex UI using reusable components"}
    }
    render(){
        return(
            <div>
                <h1>Hello {this.props.myname}, This is class component</h1><br/>
                <h3>{this.state.data}</h3>
            </div>
        )
    }

}
Employee.defaultProps={
    myname:"xxx"
}
export default Employee;