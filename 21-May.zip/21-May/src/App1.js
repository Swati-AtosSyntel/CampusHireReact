import React,{Component} from 'react';

class App1 extends React.Component{
    constructor(){
        super();
        this.state={myArr:[]}
        this.PushDataInArr=this.PushData.bind(this);
    }
    PushData(){
        var temp=this.state.myArr;
        temp.push("Hi....");
        this.setState({myArr:temp});
        alert(this.state.myArr);
    }
    render(){
        return(
            <div>
                <button onClick={this.PushDataInArr}>Change State</button>
                <h2>Update State is :</h2><h2>{this.state.myArr}</h2>
            </div>
        )
    }
}
export default App1;