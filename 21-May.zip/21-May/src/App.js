import logo from './logo.svg';
import './App.css';
import Employee from './Employee';
import Person from './person';
import App1 from './App1';
import App2 from './App2';
import Emp1 from './Emp1';
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
        <h2>Welcome To React JS frontend library</h2>
        <Emp1/>
        <App1/>
        <App2/>
        <Person/>
        <Welcome name="Swati"/>
        <Welcome name="Sai"/>
        <Employee myname="Nishant"/>
        <Employee/>
      </header>
    </div>
  );
}

function Welcome(props){
  return(
    <h2>Hi {props.name}, This is from Welcome Component</h2>
  )
}

export default App;
